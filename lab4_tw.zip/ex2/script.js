document.addEventListener('DOMContentLoaded', () => {
    
    // Obține referințele la elementele DOM esențiale
    const detaliiDiv = document.getElementById('detalii');
    const btnDetalii = document.getElementById('btnDetalii');
    const dataProdusSpan = document.getElementById('dataProdus');
    
    // Tablou de șiruri de caractere pentru lunile anului în limba română
    const NumeLuni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

    // =========================================================
    // 1. Logica la ÎNCĂRCAREA PAGINII
    // =========================================================

    // a) Ascunde secțiunea de detalii inițial
    detaliiDiv.classList.add('ascuns');
    
    // b) Obține și injectează data curentă
    function injecteazaDataCurenta() {
        const dataCurenta = new Date();
        const zi = dataCurenta.getDate();
        const lunaIndex = dataCurenta.getMonth();
        const an = dataCurenta.getFullYear();
        
        const lunaText = NumeLuni[lunaIndex];
        
        // Formatează șirul cerut: 16 Noiembrie 2025
        const dataFormatata = `${zi} ${lunaText} ${an}`;
        
        // Injectează în elementul #dataProdus
        dataProdusSpan.textContent = dataFormatata;
    }
    
    injecteazaDataCurenta();

    // =========================================================
    // 2. Logica la CLICK pe buton (Eveniment DOM)
    // =========================================================

    function comutaDetalii() {
        // a) Comută vizibilitatea secțiunii prin classList.toggle("ascuns")
        detaliiDiv.classList.toggle('ascuns');

        // b) Modifică textul butonului în funcție de starea actuală
        const esteAscuns = detaliiDiv.classList.contains('ascuns');
        
        if (esteAscuns) {
            // Detaliile sunt ascunse
            btnDetalii.textContent = "Afișează detalii";
        } else {
            // Detaliile sunt vizibile
            btnDetalii.textContent = "Ascunde detalii";
        }
    }

    // Atașează funcția la evenimentul "click" al butonului
    btnDetalii.addEventListener('click', comutaDetalii);
});