document.addEventListener('DOMContentLoaded', () => {
    // Obține referințele la elementele DOM
    const inputActivitate = document.getElementById('inputActivitate');
    const btnAdauga = document.getElementById('btnAdauga');
    const listaActivitati = document.getElementById('listaActivitati');
    
    // Tablou de șiruri de caractere pentru lunile anului în limba română
    const NumeLuni = [
        "Ianuarie", "Februarie", "Martie", "Aprilie", "Mai", "Iunie",
        "Iulie", "August", "Septembrie", "Octombrie", "Noiembrie", "Decembrie"
    ];

    // Funcția principală care adaugă activitatea
    function adaugaActivitate() {
        const textActivitate = inputActivitate.value.trim();

        // 1. Verifică dacă textul nu este gol
        if (textActivitate !== "") {
            
            // 2. Obține data curentă
            const dataCurenta = new Date();
            const zi = dataCurenta.getDate();
            const lunaIndex = dataCurenta.getMonth();
            const an = dataCurenta.getFullYear();
            
            // 3. Formatează data și obține luna în format text
            const lunaText = NumeLuni[lunaIndex];
            const dataFormatata = `${zi} ${lunaText} ${an}`;

            // 4. Creează un nou element <li>
            const newListItem = document.createElement('li');
            
            // 5. Setează conținutul elementului <li>
            // Formatul cerut: Activitate – adăugată la: 16 Noiembrie 2025;
            newListItem.innerHTML = `
                ${textActivitate}
                <span class="data"> – adăugată la: ${dataFormatata}</span>
            `;

            // 6. Adaugă elementul <li> în interiorul listei <ul>
            listaActivitati.appendChild(newListItem);

            // 7. Golește câmpul de input după adăugare
            inputActivitate.value = "";
        } else {
            alert("Te rog să introduci o activitate validă!");
        }
    }

    // Atașează funcția la evenimentul "click" al butonului
    btnAdauga.addEventListener('click', adaugaActivitate);

    // Permite adăugarea și prin apăsarea tastei Enter în câmpul de input
    inputActivitate.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            adaugaActivitate();
        }
    });
});